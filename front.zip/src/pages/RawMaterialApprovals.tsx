import React from 'react'

const RawMaterialApprovals = () => {
  return (
    <div>RawMaterialApprovals</div>
  )
}

export default RawMaterialApprovals