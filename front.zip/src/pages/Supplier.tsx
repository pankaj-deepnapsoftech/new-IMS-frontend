import React from 'react'

const Supplier = () => {
  return (
    <div>Supplier</div>
  )
}

export default Supplier