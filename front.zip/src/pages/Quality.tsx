import React from 'react'

const Quality = () => {
  return (
    <div>Quality</div>
  )
}

export default Quality