import React from 'react'

const Packaging = () => {
  return (
    <div>Packaging</div>
  )
}

export default Packaging