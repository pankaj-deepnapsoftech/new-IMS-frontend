import React from 'react'

const Maintenance = () => {
  return (
    <div>Maintenance</div>
  )
}

export default Maintenance