import React from 'react'

const Scheduling = () => {
  return (
    <div>Scheduling</div>
  )
}

export default Scheduling