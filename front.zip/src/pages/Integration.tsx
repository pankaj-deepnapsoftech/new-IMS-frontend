import React from 'react'

const Integration = () => {
  return (
    <div>Integration</div>
  )
}

export default Integration