import React from 'react'

const Planning = () => {
  return (
    <div>Planning</div>
  )
}

export default Planning