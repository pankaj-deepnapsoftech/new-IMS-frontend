import React from 'react'

const Precurement = () => {
  return (
    <div>Precurement</div>
  )
}

export default Precurement