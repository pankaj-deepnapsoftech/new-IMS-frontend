import React from 'react'

const ResourcesApproval = () => {
  return (
    <div>ResourcesApproval</div>
  )
}

export default ResourcesApproval