import React from 'react'

const Designing = () => {
  return (
    <div>Designing</div>
  )
}

export default Designing